/*************************************************************************************
 ** Program Filename: queue.cpp
 ** Author: William Dang
 ** Date: 8/11/2019
 ** Description: Implementation to simulate buffer for queue container. Generates
 ** random number N between 1 to 1000, starting with no value in the buffer. For
 ** appending/removing numbers, it generates another randomized number from 1 to 100.
 **************************************************************************************/

#include "queue.hpp"
#include <iostream>
#include <random>
#include <chrono>
#include <queue>

void randomBuffer(std::queue<int> &MyQueue, int numFront, int numBack)
{
	std::queue<int>temp;
	unsigned seed = std::chrono::system_clock::now().time_since_epoch().count();
	std::default_random_engine generator(seed);

	std::uniform_int_distribution<int> randomIntFront(1, 100);
	std::uniform_int_distribution<int> randomIntBack(1, 100);
	std::uniform_int_distribution<int> randomInt(1, 1000);

	int front = randomIntFront(generator);
	int back = randomIntBack(generator);
	int N = randomInt(generator);

	if (front <= numFront) {
		MyQueue.push(N);
	}
	else if (!MyQueue.empty() && back <= numBack) {
		MyQueue.pop();
	}
}