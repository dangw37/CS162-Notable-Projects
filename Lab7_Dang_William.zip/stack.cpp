/*************************************************************************************
 ** Program Filename: stack.cpp
 ** Author: William Dang
 ** Date: 8/11/2019
 ** Description: Implementation file for the function to create palindrome
 **************************************************************************************/

#include<iostream>
#include<string>
#include<stack>
#include<sstream>
#include<vector>

#include "stack.hpp"

using std::string;

void stackPal()
{
	std::stringstream ss;
	std::string userInput;
	std::vector<char> inputString;
	std::stack<char, std::vector<char>> InputString;
	std::stack<std::string> userPal;

	// prompt for user input to turn into palindrome
	std::cout << "Please enter a string to receive the palindrome of that string" << std::endl;
	getline(std::cin, userInput);

	// push string to stack
	for (unsigned int i = 0; i < userInput.size(); i++)
		InputString.push(userInput[i]);

	// pop when string is empty
	std::cout << userInput;
	while (!InputString.empty()) {
		std::cout << InputString.top();
		InputString.pop();
	}
}