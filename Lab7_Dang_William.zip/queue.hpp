/*************************************************************************************
 ** Program Filename: queue.hpp
 ** Author: William Dang
 ** Date: 8/11/2019
 ** Description: Header of the queue class
 **************************************************************************************/
#ifndef QUEUE_HPP
#define QUEUE_HPP

#include <iostream>
#include <cstdlib>
#include <queue>

using std::queue;

void randomBuffer(std::queue<int> &MyQueue, int numFront, int numBack);

#endif