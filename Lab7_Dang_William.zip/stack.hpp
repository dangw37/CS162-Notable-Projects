/*************************************************************************************
 ** Program Filename: stack.hpp
 ** Author: William Dang
 ** Date: 7/28/2019
 ** Description: Header file for stackPal function
 **************************************************************************************/

#ifndef STACK_HPP
#define STACK_HPP

#include <iostream>
#include <cstdlib>
#include <stack>

using std::stack;

void stackPal();

#endif