/*************************************************************************************
 ** Program Filename: main.cpp
 ** Author: William Dang
 ** Date: 8/11/2019
 ** Description: The program allows user to test a random buffer and create a palindrome.
 ** User is prompted to enter two percentages, and total number of rounds for the queue,
 ** and display round results to the console. For the stack, user is prompted to
 ** enter string and the palindrome is created and then displayed. This file also
 ** prints the menu prompts for this program.
 **************************************************************************************/

#include <iostream>
#include <queue>
#include <limits>
#include "queue.hpp"
#include "stack.hpp"
#include <string>

using std::string;

// function to validate input for menu option user input
void checkOptions(int* option)
{
	while (*option < 1 || *option > 2 || std::cin.fail())
	{
		std::cin.clear();
		std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

		std::cout << "Invalid. Please enter a valid number (1 or 2): " << std::endl;

		std::cin >> *option;
	}
}

// function to validate input for number of rounds
void checkInt(int* roundInput)
{
	while (*roundInput < 1 || *roundInput > 100 || std::cin.fail())
	{
		std::cin.clear();
		std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

		std::cout << "Invalid. Please Enter a valid number (1-100): " << std::endl;

		std::cin >> *roundInput;
	}
}

// main function
int main()
{
	int b = 0;
	double totals = 0;

	std::queue<int> q1;
	std::queue<int> temp;
	std::string playOrQuit = "p";

	while (playOrQuit != "q")
	{
		int rounds;
		int numBack;
		int numFront;
		int userNum;

		// print menu prompts
		std::cout << "Welcome to Stack and Queue STL Containers Program!" << std::endl;
		std::cout << "Please choose 1 for buffer simulator or 2 to create a palindrome. " << std::endl;
		std::cin >> userNum;
		checkOptions(&userNum);

		// prompt for rounds and probabilities for simulation
		if (userNum == 1) {
			std::cout << "Enter the number of rounds for the simulation?" << std::endl;
			std::cin >> rounds;
			checkInt(&rounds);
			std::cout << "Enter probability of adding a number to the front of the buffer (1-100, i.e. 10 = 10%)? " << std::endl;
			std::cin >> numFront;
			checkInt(&numFront);
			std::cout << "Enter probability of adding a number to the back of the buffer (1-100, i.e. 10 = 10%)? " << std::endl;
			std::cin >> numBack;
			checkInt(&numBack);

			for (int i = 0; i < rounds; i++) {
				randomBuffer(q1, numFront, numBack);
				b++;
			}

			temp = q1;
			// display length of buffer
			while (!temp.empty())
			{
				std::cout << temp.front() << std::endl;
				temp.pop();
			}
			std::cout << "Length of buffer: " << q1.size() << std::endl;

			// display average length of buffer
			totals += q1.size();
			std::cout << "Average length of buffer = " << (totals / (b + 1) * 100) << std::endl << std::endl;
		}
		// if user selects 2, call function to create palindrome from user input
		else if (userNum == 2) {
			std::cin.clear();
			std::cin.ignore();
			stackPal();
			std::cout << std::endl << std::endl;
		}

		std::cin.clear();
		std::cout << "Enter p to play again or q to quit" << std::endl;
		std::cin >> playOrQuit;
		bool validChar = false;

		// validate user input character to play again or quit
		while (validChar == false) {
			std::cin.clear();
			if (playOrQuit.length() > 1) {
				validChar = false;
				std::cin.clear();
				std::cout << "Please enter either p or q " << std::endl;
				std::cin >> playOrQuit;
			}
			else if (!isalpha(playOrQuit.at(0))) {
				validChar = false;
				std::cin.clear();
				std::cout << "Please enter either p or q  " << std::endl;
				std::cin >> playOrQuit;
			}
			else {
				char c = tolower(playOrQuit.at(0));
				if (c == 'p' || c == 'q')
					validChar = true;
				else {
					validChar = false;
					std::cin.clear();
					std::cout << "Please enter either p or q  " << std::endl;
					std::cin >> playOrQuit;
				}
			}
		}
	}
	return 0;
}